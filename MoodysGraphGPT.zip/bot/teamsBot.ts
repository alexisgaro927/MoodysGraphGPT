import {
  TeamsActivityHandler,
  CardFactory,
  TurnContext,
  AdaptiveCardInvokeValue,
  AdaptiveCardInvokeResponse,
} from "botbuilder";
import rawWelcomeCard from "./adaptiveCards/welcome.json";
import { AdaptiveCards } from "@microsoft/adaptivecards-tools";
import { Configuration, OpenAIApi } from "openai";
import config from "./config";

export class TeamsBot extends TeamsActivityHandler {
  constructor() {
    super();



//OpenAI Call


    const configuration = new Configuration({
      apiKey: //'insert api key here',
    });
    const openai = new OpenAIApi(configuration);

    this.onMessage(async (context, next) => {
      console.log("Running with Message Activity.");

      let txt = context.activity.text;
      const removedMentionText = TurnContext.removeRecipientMention(context.activity);
      if (removedMentionText) {
        // Remove the line break
        txt = removedMentionText.toLowerCase().replace(/\n|\r/g, "").trim();
      }

      const response = await openai.createCompletion({
        model: "text-davinci-003",
        prompt: txt,
        temperature: 0,
        max_tokens: 4000,
      });

      
      const message2 = "OpenAI: "+ response.data.choices[0].text; 
      await context.sendActivity(message2);



//Azure OpenAI Call

     const axios = require('axios');
      let data = JSON.stringify({
        "messages": [
          {
            "role": "system",
            "content": "You are an AI assistant that helps people find information."
          },
          {
            "role": "user",
            "content": txt
          }
        ],
        "max_tokens": 8000,
        "temperature": 0,
        "frequency_penalty": 0,
        "presence_penalty": 0,
        "top_p": 1,
        "stop": null
      });
      
      let config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: 'https://1ws3s3.openai.azure.com/openai/deployments/gpt35qna/chat/completions?api-version=2023-03-15-preview',
        headers: { 
          'Content-Type': 'application/json', 
          'api-key': //'insert api key here'
        },
        data : data
      };
      



      let message;

      try {
        const response = await axios.request(config);
        const message = "Azure OpenAI: " + response.data.choices[0].message.content;
        await context.sendActivity(message);
      } catch (error) {
        console.log(error);
      }


//Openrouter.ai call (anthropic/claude-2)
//'insert api key here'

const axiosOpenRouter = require('axios');

try {
  const response = await axiosOpenRouter({
    method: 'post',
    url: 'https://openrouter.ai/api/v1/chat/completions',
    headers: {
      'Authorization': //'insert api key here',
      'HTTP-Referer': 'https://agnai.chat', // To identify your app
      //'X-Title': process.env.YOUR_APP_NAME
    },
    data: {
      model: "anthropic/claude-2", // Optional (user controls the default)
      messages: [{"role": "system", "content": "You are a helpful assistant."}, {"role": "user", "content": txt}]
    }
  });

  console.log(response.data);
  const message = "OpenRouterAI (anthropic/claude-2): " + response.data.choices[0].message.content;
  await context.sendActivity(message);
} catch (error) {
  console.log(error);
}







//Openrouter.ai call (google/palm-2-chat-bison)
//'insert api key here'

const axiosOpenRouter2 = require('axios');

try {
  const response = await axiosOpenRouter({
    method: 'post',
    url: 'https://openrouter.ai/api/v1/chat/completions',
    headers: {
      'Authorization': //'insert api key here',
      'HTTP-Referer': 'https://agnai.chat', // To identify your app
      //'X-Title': process.env.YOUR_APP_NAME
    },
    data: {
      model: "google/palm-2-chat-bison", // Optional (user controls the default)
      messages: [{"role": "system", "content": "You are a helpful assistant."}, {"role": "user", "content": txt}]
    }
  });

  console.log(response.data);
  const message = "OpenRouterAI (anthropic/google/palm-2-chat-bison): " + response.data.choices[0].message.content;
  await context.sendActivity(message);
} catch (error) {
  console.log(error);
}




//Openrouter.ai call (openai/gpt-4-32k)
//'insert api key here'

const axiosOpenRouter3 = require('axios');

try {
  const response = await axiosOpenRouter({
    method: 'post',
    url: 'https://openrouter.ai/api/v1/chat/completions',
    headers: {
      'Authorization': //'insert api key here',
      'HTTP-Referer': 'https://agnai.chat', // To identify your app
      //'X-Title': process.env.YOUR_APP_NAME
    },
    data: {
      model: "openai/gpt-4-32k", // Optional (user controls the default)
      messages: [{"role": "system", "content": "You are a helpful assistant."}, {"role": "user", "content": txt}]
    }
  });

  console.log(response.data);
  const message = "OpenRouterAI (openai/gpt-4-32k): " + response.data.choices[0].message.content;
  await context.sendActivity(message);
} catch (error) {
  console.log(error);
}




//Openrouter.ai call (meta-llama/llama-2-70b-chat)
//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

const axiosOpenRouter4 = require('axios');

try {
  const response = await axiosOpenRouter({
    method: 'post',
    url: 'https://openrouter.ai/api/v1/chat/completions',
    headers: {
      'Authorization': //'insert api key here',
      'HTTP-Referer': 'https://agnai.chat', // To identify your app
      //'X-Title': process.env.YOUR_APP_NAME
    },
    data: {
      model: "meta-llama/llama-2-70b-chat", // Optional (user controls the default)
      messages: [{"role": "system", "content": "You are a helpful assistant."}, {"role": "user", "content": txt}]
    }
  });

  console.log(response.data);
  const message = "OpenRouterAI (anthropic/meta-llama/llama-2-70b-chat): " + response.data.choices[0].message.content;
  await context.sendActivity(message);
} catch (error) {
  console.log(error);
}




      // By calling next() you ensure that the next BotHandler is run.
      await next();
    });

    this.onMembersAdded(async (context, next) => {
      const membersAdded = context.activity.membersAdded;
      for (let cnt = 0; cnt < membersAdded.length; cnt++) {
        if (membersAdded[cnt].id) {
          const card = AdaptiveCards.declareWithoutData(rawWelcomeCard).render();
          await context.sendActivity({ attachments: [CardFactory.adaptiveCard(card)] });
          break;
        }
      }
      await next();
    });
  }
}